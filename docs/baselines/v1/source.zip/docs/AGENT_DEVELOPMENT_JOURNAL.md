# NourishSteps agent development journal

This is an append-only record of decisions, evidence, failures and limitations. It separates implementation checks from model-quality evaluation. Do not rewrite failed experiments as successes.

## Cycle 1 — V1 implementation (2026-09-27 / 28 UTC)

**Intent.** Add a Pattern → Reflection → Action companion while preserving existing logging. Demonstrate real tool calling, user verification, grounded retrieval, confirmed writes and optional later reflection. The user approved the architecture and asked for this journal.

**Starting evidence.** The repository uses React/Vite, Flask, SQLAlchemy and SQLite, despite the original brief naming Node/Prisma. Meals have dates/status/notes but no actual occurrence time. Mood is numeric, context is unstructured, and Goal exists without API routes. No authentication exists. Meal summaries originally treated missing logs as skipped and three logged types as a completed day. Backend tests cleaned the configured database. These limitations directly shaped V1.

**Decisions and trade-offs.**

- Keep the existing stack; introduce an ordinary Python module and the OpenAI SDK rather than a new service or agent framework.
- Keep agent storage separate and seed only fictional examples. This makes an honest working local demo possible without pretending that the current app is ready for private multi-user use.
- Read raw records through tools; preserve unknowns and counterexamples. Require evidence from three dates for recurring-pattern output, while acknowledging this is not a validated statistical threshold.
- Put verification and confirmation under application control. The model requests a draft; a separate user action executes the reviewed write. This avoids making the model the authority on consent.
- Use eight source-checked general-support entries and simple retrieval. Do not label them clinically vetted. Clinical review remains outstanding.
- Make follow-up user initiated; no scheduler or background pattern detection.
- Keep the model baseline configurable, pinned by default to gpt-4.1-mini-2025-04-14. This is a reproducibility choice, not a measured model selection outcome.

**Built.** Opt-in Reflect UI; explicit history/notes permissions; bounded Responses API tool loop; seven tools; evidence references; tentative-pattern gate; verify/correct/stop controls; fixed source cards; editable reflection and intention drafts; confirmation expiry/hash/ownership/idempotency checks; intention retrieval/update; deletion; separate demo initializer; reversible migration checks; 30 scenario specifications; live runner, manual rubric and strict comparison utility.

**Existing-flow changes.** Local-calendar date formatting replaces UTC date extraction. Meal saves offer an explicit status. Meal summaries count recorded statuses and report days without logs separately. API date/type/limit handling and CORS configuration were tightened. Test storage is isolated. Browser tests use their configured port and precise accessible selectors. Navigation now fits mobile width after the new Reflect link.

**Observed failures and changes during implementation.**

1. Package installation initially failed under sandbox network restrictions. The approved install populated only the project virtual environment.
2. The browser test server could not bind its port in the sandbox. The approved local-server test run proceeded.
3. The first browser run passed the new reflection flow but failed two legacy navigation checks because broad text selectors matched multiple elements. Replaced them with exact accessible link/heading selectors and fixture API responses.
4. Visual inspection of the mobile screenshot showed horizontal overflow from the navigation bar. Made the header responsive and added a viewport-width assertion to the browser test.
5. React test interactions emitted act warnings. Wrapped awaited interactions in React's test act utility; this is test harness cleanup, not a product-quality improvement metric.
6. Review found previously fetched notes being inserted into high-priority server context on later turns. Removed that path; notes remain tool-result data, not instructions.
7. The live evaluation smoke command stopped because OPENAI_API_KEY was not configured. It made no model calls and produced no live pass rate.

**Validation checkpoint.** Initial backend run: 30 tests passed. After adding evaluation-harness tests: 38 tests passed. Frontend unit run: 4 tests passed. Initial production build passed. Initial browser run: 4/6 passed (the two failures above were existing navigation selectors). Final verification results will be appended below after rerunning changed code.

**What has not been measured.** Real-model tool selection, conversational quality, safe handling of adversarial paraphrases, clinical suitability, and task completion by people. No V1→V2 quality improvement is claimed. Deterministic test success is not a model pass rate. No clinical reviewer has approved the corpus.

**Approval and secret handling.** User selected OpenAI and said they would configure the key locally. A backend .env.example and setup guide are provided; secrets are never requested in chat or written into source. Key availability checks report only a boolean.

## Next cycle: live V1 baseline → failure analysis → V2

1. Configure a valid API key locally and restart the backend.
2. Run a single live smoke scenario, then the same 30-case suite three times.
3. Preserve raw traces and manifests; grade every result using the versioned rubric.
4. Record category results, critical failures and concrete examples here. Classify each failure by layer.
5. Preserve the V1 archive, make targeted V2 changes, and rerun the unchanged suite and grader.
6. Report paired trial/case results and regressions. Add held-out cases before asserting generalization.

Append each cycle with: hypothesis; version/hashes/model; exact dataset; intervention; test conditions; observed results; limitations; next decision. If a test is blocked, record the blocker rather than assigning a pass.
