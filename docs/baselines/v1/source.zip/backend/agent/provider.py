"""Only module that knows the provider SDK. Tests inject a scripted provider."""
import json
import os
from agent.policy import FINAL_SCHEMA

class ProviderUnavailable(RuntimeError):
    pass

class OpenAIProvider:
    def __init__(self):
        from openai import OpenAI
        if not os.getenv('OPENAI_API_KEY'):
            raise ProviderUnavailable('Set OPENAI_API_KEY on the backend to enable reflection.')
        self.client = OpenAI(timeout=20, max_retries=0)
        self.model = os.getenv('OPENAI_MODEL', 'gpt-4.1-mini-2025-04-14')

    def respond(self, instructions, inputs, tools):
        response = self.client.responses.create(
            model=self.model, instructions=instructions, input=inputs, tools=tools,
            parallel_tool_calls=False, store=False, max_output_tokens=1600,
            text={'format':{'type':'json_schema','name':'reflection_reply','strict':True,'schema':FINAL_SCHEMA}},
        )
        calls = [{'name':i.name,'arguments':i.arguments,'call_id':i.call_id} for i in response.output if i.type == 'function_call']
        # Reasoning items may need round-tripping; never log or expose them.
        items = [i.model_dump(exclude_none=True) for i in response.output]
        return {'calls':calls,'items':items,'output':None if calls else json.loads(response.output_text),
                'usage':response.usage.model_dump() if response.usage else {}}
